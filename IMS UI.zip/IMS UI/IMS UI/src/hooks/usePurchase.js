import { useState } from "react";

export default function usePurchase() {
  const [vendors, setVendors] = useState([]);
  const [categories, setCategories] = useState([]);
  const [types, setTypes] = useState([]);
  const [units, setUnits] = useState([]);

  return {
    vendors,
    categories,
    types,
    units,
  };
}