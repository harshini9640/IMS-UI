import { useEffect, useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import toast from "react-hot-toast";
import { Save } from "lucide-react";
import SuccessModal from "./ui/SuccessModal";

import { purchaseSchema } from "../schemas/purchaseSchema";

import {
    getVendors,
    getCategories,
    getUnitAndTypeList,
    addPurchase,
} from "../services/inventoryService";

import Button from "./ui/Button";
import Input from "./ui/Input";
import Select from "./ui/Select";

export default function PurchaseForm() {
    const {
        register,
        handleSubmit,
        watch,
        reset,
        setValue,
        formState: { errors },
    } = useForm({
        resolver: zodResolver(purchaseSchema),
        defaultValues: {
            vendorName: "",
            materialCategoryId: "",
            materialTypeId: "",
            unitId: "",
            brandName: "",
            quantity: "",
            purchaseDate: "",
            purchaseAmount: "",
        },
    });

    const [vendors, setVendors] = useState([]);
    const [categories, setCategories] = useState([]);
    const [types, setTypes] = useState([]);
    const [units, setUnits] = useState([]);

    const [loadingVendors, setLoadingVendors] = useState(true);
    const [loadingCategories, setLoadingCategories] = useState(false);
    const [loadingTypes, setLoadingTypes] = useState(false);
    const [saving, setSaving] = useState(false);
    const [successData, setSuccessData] = useState(null);

    const selectedVendor = watch("vendorName");
    const selectedCategory = watch("materialCategoryId");

    // =====================================================
    // Load Vendors
    // =====================================================

    useEffect(() => {
        const loadVendors = async () => {
            try {
                setLoadingVendors(true);

                const data = await getVendors();

                setVendors(data);
            } catch (err) {
                console.error(err);
                toast.error("Unable to load vendors");
            } finally {
                setLoadingVendors(false);
            }
        };

        loadVendors();
    }, []);

    // =====================================================
    // Load Categories
    // =====================================================

    useEffect(() => {
        if (!selectedVendor) {
            setCategories([]);
            setTypes([]);
            setUnits([]);

            setValue("materialCategoryId", "");
            setValue("materialTypeId", "");
            setValue("unitId", "");

            return;
        }

        const loadCategories = async () => {
            try {
                setLoadingCategories(true);

                const data = await getCategories();

                setCategories(data);
            } catch (err) {
                console.error(err);
                toast.error("Unable to load categories");
            } finally {
                setLoadingCategories(false);
            }
        };

        loadCategories();
    }, [selectedVendor, setValue]);

    // =====================================================
    // Load Material Types & Units
    // =====================================================

    useEffect(() => {
        if (!selectedCategory) {
            setTypes([]);
            setUnits([]);

            setValue("materialTypeId", "");
            setValue("unitId", "");

            return;
        }

        const loadMaterialData = async () => {
            try {
                setLoadingTypes(true);

                const data = await getUnitAndTypeList(selectedCategory);

                setTypes(data.materialTypeList || []);
                setUnits(data.unitList || []);
            } catch (err) {
                console.error(err);
                toast.error("Unable to load material data");
            } finally {
                setLoadingTypes(false);
            }
        };

        loadMaterialData();
    }, [selectedCategory, setValue]);

    // =====================================================
    // Submit
    // =====================================================

    const onSubmit = async (formData) => {
        setSuccessData(null);
        try {
            setSaving(true);

            const response = await addPurchase(formData);

            setSuccessData({
                message: response.message,
                transactionId: response.purchase.transactionId,
            });

            reset();

            setCategories([]);
            setTypes([]);
            setUnits([]);
        } catch (error) {
            toast.error(
                error.response?.data?.message ||
                "Failed to save purchase."
            );
        } finally {
            setSaving(false);
        }
    };

    return (
        <>
            <form
                onSubmit={handleSubmit(onSubmit)}
                className="space-y-8"
            >
                <div className="grid gap-6 md:grid-cols-2">

                    {/* Vendor */}

                    <Select
                        label="Vendor"
                        disabled={loadingVendors}
                        error={errors.vendorName?.message}
                        {...register("vendorName")}
                    >
                        <option value="">
                            {loadingVendors
                                ? "Loading Vendors..."
                                : "Select Vendor"}
                        </option>

                        {vendors.map((vendor) => (
                            <option
                                key={vendor.vendorId}
                                value={vendor.vendorName}
                            >
                                {vendor.vendorName}
                            </option>
                        ))}
                    </Select>

                    {/* Category */}

                    <Select
                        label="Material Category"
                        disabled={!selectedVendor || loadingCategories}
                        error={errors.materialCategoryId?.message}
                        {...register("materialCategoryId")}
                    >
                        <option value="">
                            {!selectedVendor
                                ? "Select Vendor First"
                                : loadingCategories
                                    ? "Loading Categories..."
                                    : "Select Category"}
                        </option>

                        {categories.map((category) => (
                            <option
                                key={category.categoryId}
                                value={category.categoryId}
                            >
                                {category.categoryName}
                            </option>
                        ))}
                    </Select>

                    {/* Material Type */}

                    <Select
                        label="Material Type"
                        disabled={!selectedCategory || loadingTypes}
                        error={errors.materialTypeId?.message}
                        {...register("materialTypeId")}
                    >
                        <option value="">
                            {!selectedCategory
                                ? "Select Category First"
                                : loadingTypes
                                    ? "Loading Types..."
                                    : "Select Type"}
                        </option>

                        {types.map((type) => (
                            <option
                                key={type.typeId}
                                value={type.typeId}
                            >
                                {type.typeName}
                            </option>
                        ))}
                    </Select>

                    {/* Unit */}

                    <Select
                        label="Unit"
                        disabled={!selectedCategory || loadingTypes}
                        error={errors.unitId?.message}
                        {...register("unitId")}
                    >
                        <option value="">
                            {!selectedCategory
                                ? "Select Category First"
                                : loadingTypes
                                    ? "Loading Units..."
                                    : "Select Unit"}
                        </option>

                        {units.map((unit) => (
                            <option
                                key={unit.unitId}
                                value={unit.unitId}
                            >
                                {unit.unitName}
                            </option>
                        ))}
                    </Select>

                    {/* Brand */}

                    <Input
                        label="Brand Name"
                        placeholder="Enter brand name"
                        error={errors.brandName?.message}
                        {...register("brandName")}
                    />

                    {/* Quantity */}

                    <Input
                        type="number"
                        label="Quantity"
                        placeholder="Enter quantity"
                        error={errors.quantity?.message}
                        {...register("quantity")}
                    />

                    {/* Purchase Date */}

                    <Input
                        type="date"
                        label="Purchase Date"
                        max={new Date().toISOString().split("T")[0]}
                        error={errors.purchaseDate?.message}
                        {...register("purchaseDate")}
                    />

                    {/* Purchase Amount */}

                    <Input
                        type="number"
                        label="Purchase Amount"
                        placeholder="Enter purchase amount"
                        error={errors.purchaseAmount?.message}
                        {...register("purchaseAmount")}
                    />
                </div>

                <div className="flex justify-end">
                    <Button
                        type="submit"
                        loading={saving}
                        className="w-full md:w-56"
                    >
                        <Save size={18} />
                        Save Purchase
                    </Button>
                </div>
            </form>
            <SuccessModal
                open={successData !== null}
                message={successData?.message}
                transactionId={successData?.transactionId}
                onClose={() => setSuccessData(null)}
            />
        </>
    );
}