export default function ReportTable({ reports }) {
  if (!reports.length) return null;

  return (
    <div className="overflow-auto rounded-xl border">

      <table className="min-w-full text-sm">

        <thead className="bg-slate-100">

          <tr>

            <th className="p-3 text-left">Transaction ID</th>

            <th className="p-3 text-left">Vendor</th>

            <th className="p-3 text-left">Brand</th>

            <th className="p-3 text-left">Category</th>

            <th className="p-3 text-left">Type</th>

            <th className="p-3 text-left">Quantity</th>

            <th className="p-3 text-left">Amount</th>

            <th className="p-3 text-left">Status</th>

          </tr>

        </thead>

        <tbody>

          {reports.map((purchase) => (
            <tr
              key={purchase.purchaseId}
              className="border-t"
            >
              <td className="p-3">{purchase.transactionId}</td>

              <td className="p-3">{purchase.vendorName}</td>

              <td className="p-3">{purchase.brandName}</td>

              <td className="p-3">{purchase.materialCategoryId}</td>

              <td className="p-3">{purchase.materialTypeId}</td>

              <td className="p-3">{purchase.quantity}</td>

              <td className="p-3">₹ {purchase.purchaseAmount}</td>

              <td className="p-3">{purchase.status}</td>
            </tr>
          ))}

        </tbody>

      </table>

    </div>
  );
}