import { Package } from "lucide-react";

export default function Header() {
  return (
    <header className="bg-gradient-to-r from-slate-900 via-indigo-700 to-violet-600 shadow-xl shadow-slate-950/20">
      <div className="mx-auto flex max-w-7xl flex-col gap-4 px-6 py-8 md:flex-row md:items-center md:justify-between">

        <div className="flex items-center gap-4">
          <div className="flex h-14 w-14 items-center justify-center rounded-3xl bg-white/10 text-white shadow-lg shadow-slate-950/20">
            <Package className="h-6 w-6" />
          </div>

          <div>
            <h1 className="text-3xl font-semibold text-white md:text-4xl">
              Inventory Management System
            </h1>
            <p className="mt-1 text-sm text-slate-200 md:text-base">
              Vendor and metrial management 
            </p>
          </div>
        </div>


      </div>
    </header>
  );
}