export default function Navigation({ page, setPage }) {
    return (
        <div className="flex flex-wrap gap-3">
            <button
                onClick={() => setPage("purchase")}
                className={`rounded-full px-6 py-3 text-sm font-semibold transition-all duration-300 focus:outline-none focus-visible:ring-2 focus-visible:ring-indigo-300 ${
                    page === "purchase"
                        ? "bg-white text-slate-950 shadow-[0_15px_40px_-25px_rgba(15,23,42,0.7)]"
                        : "border border-slate-700/60 bg-slate-900/70 text-slate-200 hover:border-indigo-300 hover:bg-slate-800"
                }`}
            >
                Add Purchase
            </button>
            <button
                onClick={() => setPage("report")}
                className={`rounded-full px-6 py-3 text-sm font-semibold transition-all duration-300 focus:outline-none focus-visible:ring-2 focus-visible:ring-indigo-300 ${
                    page === "report"
                        ? "bg-white text-slate-950 shadow-[0_15px_40px_-25px_rgba(15,23,42,0.7)]"
                        : "border border-slate-700/60 bg-slate-900/70 text-slate-200 hover:border-indigo-300 hover:bg-slate-800"
                }`}
            >
                Reports
            </button>
        </div>
    );
}