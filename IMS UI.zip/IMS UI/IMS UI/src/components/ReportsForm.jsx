import { useEffect, useState } from "react";
import { useForm } from "react-hook-form";
import { Search } from "lucide-react";

import { getVendors, getPurchaseReport } from "../services/inventoryService";

import Button from "./ui/Button";
import Card from "./ui/Card";
import Input from "./ui/Input";
import Select from "./ui/Select";

export default function ReportsForm() {
  const {
    register,
    handleSubmit,
  } = useForm({
    defaultValues: {
      vendorName: "",
      fromDate: "",
      toDate: "",
    },
  });

  const [vendors, setVendors] = useState([]);
  const [loading, setLoading] = useState(true);
  const [searching, setSearching] = useState(false);
  const [reportData, setReportData] = useState([]);

  useEffect(() => {
    const loadVendors = async () => {
      try {
        const data = await getVendors();
        setVendors(data);
      } finally {
        setLoading(false);
      }
    };

    loadVendors();
  }, []);

  const onSubmit = async (formData) => {
    try {
      setSearching(true);

      const data = await getPurchaseReport(formData);

      setReportData(data);
    } catch (err) {
      console.error(err);
    } finally {
      setSearching(false);
    }
  };

  return (
    <Card
      title="Vendor Purchase Report"
      subtitle="Search purchases made between two dates."
    >
      <form
        onSubmit={handleSubmit(onSubmit)}
        className="space-y-6"
      >
        <div className="grid gap-6 md:grid-cols-3">

          <Select
            label="Vendor"
            disabled={loading}
            {...register("vendorName")}
          >
            <option value="">
              Select Vendor
            </option>

            {vendors.map((vendor) => (
              <option
                key={vendor.vendorId}
                value={vendor.vendorName}
              >
                {vendor.vendorName}
              </option>
            ))}
          </Select>

          <Input
            type="date"
            label="From Date"
            max={new Date().toISOString().split("T")[0]}
            {...register("fromDate")}
          />

          <Input
            type="date"
            label="To Date"
            max={new Date().toISOString().split("T")[0]}
            {...register("toDate")}
          />

        </div>

        <div className="flex justify-end">

          <Button
            type="submit"
            loading={searching}
            className="w-full md:w-52"
          >
            <Search size={18} />
            Get Report
          </Button>

        </div>
      </form>

      {/* Report Table */}

      {reportData.length > 0 && (
        <div className="mt-8 overflow-x-auto">

          <table className="min-w-full border border-slate-200 rounded-lg">

            <thead className="bg-slate-100">

              <tr>
                <th className="p-3 text-left">Transaction ID</th>
                <th className="p-3 text-left">Brand</th>
                <th className="p-3 text-left">Quantity</th>
                <th className="p-3 text-left">Amount</th>
                <th className="p-3 text-left">Purchase Date</th>
                <th className="p-3 text-left">Status</th>
              </tr>

            </thead>

            <tbody>

              {reportData.map((purchase) => (

                <tr
                  key={purchase.purchaseId}
                  className="border-t hover:bg-slate-50"
                >
                  <td className="p-3 font-mono text-indigo-600">
                    {purchase.transactionId}
                  </td>

                  <td className="p-3">
                    {purchase.brandName}
                  </td>

                  <td className="p-3">
                    {purchase.quantity}
                  </td>

                  <td className="p-3">
                    ₹{purchase.purchaseAmount}
                  </td>

                  <td className="p-3">
                    {purchase.purchaseDate}
                  </td>

                  <td className="p-3">
                    <span className="rounded-full bg-green-100 px-3 py-1 text-sm font-medium text-green-700">
                      {purchase.status}
                    </span>
                  </td>

                </tr>

              ))}

            </tbody>

          </table>

        </div>
      )}

      {!searching &&
        reportData.length === 0 && (
          <div className="mt-8 rounded-xl border border-dashed border-slate-300 p-8 text-center text-slate-500">
            Search a vendor to view purchase history.
          </div>
        )}

    </Card>
  );
}