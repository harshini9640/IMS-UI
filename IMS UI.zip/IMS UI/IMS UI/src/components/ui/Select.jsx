import { forwardRef } from "react";

const Select = forwardRef(
    ({ label, children, error, className = "", ...props }, ref) => {
        return (
            <div className="space-y-2">
                <label className="text-sm font-medium text-slate-700">
                    {label}
                </label>

                <select
                    ref={ref}
                    {...props}
                    className={`
                        h-11
                        w-full
                        rounded-xl
                        border
                        px-4
                        transition
                        outline-none
                        ${props.disabled
                            ? "bg-slate-100 text-slate-400 cursor-not-allowed"
                            : "bg-white border-slate-300 focus:border-indigo-500 focus:ring-2 focus:ring-indigo-100"
                        }
`}
                >
                    {children}
                </select>

                {error && (
                    <p className="text-sm text-red-500">
                        {error}
                    </p>
                )}
            </div>
        );
    }
);

Select.displayName = "Select";

export default Select;