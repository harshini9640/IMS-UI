export default function Card({ title, subtitle, children }) {
  return (
    <div className="rounded-[30px] border border-white/10 bg-slate-950/95 p-8 shadow-[0_40px_120px_-50px_rgba(15,23,42,0.75)]">
      {(title || subtitle) && (
        <div className="mb-6">
          {title && (
            <h2 className="text-2xl font-semibold text-white">
              {title}
            </h2>
          )}

          {subtitle && (
            <p className="mt-2 text-sm text-slate-300">
              {subtitle}
            </p>
          )}
        </div>
      )}

      {children}
    </div>
  );
}