import { CheckCircle2 } from "lucide-react";

export default function SuccessModal({
    open,
    onClose,
    message,
    transactionId,
}) {
    if (!open) return null;

    return (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 backdrop-blur-sm">

            <div className="w-full max-w-md rounded-3xl bg-white p-8 shadow-2xl animate-in fade-in zoom-in-95 duration-300">

                <div className="flex flex-col items-center">

                    <div className="flex h-20 w-20 items-center justify-center rounded-full bg-green-100">

                        <CheckCircle2
                            size={52}
                            className="text-green-600"
                        />

                    </div>

                    <h2 className="mt-5 text-2xl font-bold text-slate-800">
                        Purchase Saved
                    </h2>

                    <p className="mt-2 text-center text-slate-500">
                        {message}
                    </p>

                    <div className="mt-6 w-full rounded-2xl bg-slate-50 p-5">

                        <p className="text-sm text-slate-500">
                            Transaction ID
                        </p>

                        <p className="mt-2 break-all font-mono text-xl font-semibold text-indigo-600">
                            {transactionId}
                        </p>

                    </div>

                    <button
                        onClick={onClose}
                        className="mt-8 w-full rounded-xl bg-indigo-600 py-3 font-semibold text-white transition hover:bg-indigo-700"
                    >
                        Done
                    </button>

                </div>

            </div>

        </div>
    );
}