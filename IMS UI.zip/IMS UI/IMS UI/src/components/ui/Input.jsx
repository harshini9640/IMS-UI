import { forwardRef } from "react";

const Input = forwardRef(
  ({ label, error, className = "", ...props }, ref) => {
    return (
      <div className="space-y-2">
        <label className="text-sm font-medium text-slate-700">
          {label}
        </label>

        <input
          ref={ref}
          {...props}
          className={`
            h-11
            w-full
            rounded-xl
            border
            border-slate-300
            bg-white
            px-4
            text-sm
            outline-none
            transition-all
            duration-200
            focus:border-indigo-500
            focus:ring-2
            focus:ring-indigo-100
            ${className}
          `}
        />

        {error && (
          <p className="text-sm text-red-500">
            {error}
          </p>
        )}
      </div>
    );
  }
);

Input.displayName = "Input";

export default Input;