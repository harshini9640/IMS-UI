import Spinner from "./Spinner";

export default function Button({
  children,
  loading = false,
  disabled = false,
  className = "",
  ...props
}) {
  return (
    <button
      disabled={loading || disabled}
      className={`
        flex
        h-11
        items-center
        justify-center
        gap-2
        rounded-xl
        bg-indigo-600
        px-6
        font-medium
        text-white
        transition-all
        duration-200
        hover:bg-indigo-700
        disabled:cursor-not-allowed
        disabled:opacity-60
        ${className}
      `}
      {...props}
    >
      {loading ? (
        <>
          <Spinner size={18} />
          Loading...
        </>
      ) : (
        children
      )}
    </button>
  );
}