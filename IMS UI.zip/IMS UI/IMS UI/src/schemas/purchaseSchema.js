import { z } from "zod";

export const purchaseSchema = z.object({
    vendorName: z.string().min(1, "Vendor is required"),

    materialCategoryId: z.string().min(1, "Category is required"),

    materialTypeId: z.string().min(1, "Material Type is required"),

    unitId: z.string().min(1, "Unit is required"),

    brandName: z.string().min(2, "Brand name is required"),

    quantity: z.coerce
        .number()
        .positive("Quantity must be greater than 0"),

    purchaseAmount: z.coerce
        .number()
        .positive("Amount must be greater than 0"),

    purchaseDate: z
        .string()
        .min(1, "Purchase date is required")
        .refine((date) => {
            const selected = new Date(date);
            const today = new Date();

            selected.setHours(0, 0, 0, 0);
            today.setHours(0, 0, 0, 0);

            return selected <= today;
        }, {
            message: "Purchase date cannot be in the future",
        }),
});