import { useState } from "react";

import Header from "./components/layout/Header";
import Navigation from "./components/layout/Navigation";
import PurchasePage from "./pages/PurchasePage";
import ReportsPage from "./pages/ReportsPage";

function App() {
  const [page, setPage] = useState("purchase");
  return (
    <div className="min-h-screen bg-slate-950 text-slate-100">
      <Header />

      <main className="mx-auto max-w-7xl px-6 py-10">
        <div className="rounded-[32px] border border-white/10 bg-white/5 p-6 shadow-[0_30px_80px_-40px_rgba(15,23,42,0.8)] backdrop-blur-lg">
          <Navigation page={page} setPage={setPage} />
        </div>

        <div className="mt-8 space-y-8">
          {page === "purchase" ? <PurchasePage /> : <ReportsPage />}
        </div>
      </main>
    </div>
  );
}

export default App;