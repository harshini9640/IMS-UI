export const PAGE = {
  PURCHASE: "purchase",
  REPORT: "report",
};