import api from "./api";

export const getVendors = async () => {
  const { data } = await api.get("/vendors");
  return data;
};

export const getCategories = async () => {
  const { data } = await api.get("/categories");
  return data;
};

export const getUnitAndTypeList = async (categoryId) => {
  const { data } = await api.post("/getUnitAndTypeList", {
    materialCategoryId: categoryId,
  });

  return data;
};

export const addPurchase = async (purchaseData) => {
  const { data } = await api.post("/addPurchaseDetail", purchaseData);
  return data;
};

export const getPurchaseReport = async (reportData) => {
  const { data } = await api.post(
    "/report/controller/getPurchaseDetails",
    reportData
  );

  return data;
};