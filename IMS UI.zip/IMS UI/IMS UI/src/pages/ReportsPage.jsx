import ReportsForm from "../components/ReportsForm";

export default function ReportsPage() {
  return (
    <div className="mx-auto max-w-7xl">
      <ReportsForm />
    </div>
  );
}