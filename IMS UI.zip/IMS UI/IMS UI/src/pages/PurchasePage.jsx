import Card from "../components/ui/Card";
import PurchaseForm from "../components/PurchaseForm";

export default function PurchasePage() {
  return (
    <div className="mx-auto max-w-6xl">
      <Card
        title="Purchase Details"
        subtitle="Fill in the information below to create a purchase transaction."
      >
        <PurchaseForm />
      </Card>
    </div>
  );
}